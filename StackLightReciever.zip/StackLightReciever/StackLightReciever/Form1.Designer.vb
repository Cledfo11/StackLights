﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lbl5100Integration1 = New System.Windows.Forms.Label()
        Me.lbl5100EPanel = New System.Windows.Forms.Label()
        Me.lbl5100ZAxis = New System.Windows.Forms.Label()
        Me.lbl5100Lids = New System.Windows.Forms.Label()
        Me.lbl5100Integration2 = New System.Windows.Forms.Label()
        Me.lblEOL = New System.Windows.Forms.Label()
        Me.lblCrating = New System.Windows.Forms.Label()
        Me.lblCPO = New System.Windows.Forms.Label()
        Me.lblFirmAssem = New System.Windows.Forms.Label()
        Me.lblFocusIrr = New System.Windows.Forms.Label()
        Me.lblMODIntegration1 = New System.Windows.Forms.Label()
        Me.lblModEPanel = New System.Windows.Forms.Label()
        Me.lblMDM = New System.Windows.Forms.Label()
        Me.lblMODZAxis = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblCatchTray = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblShipKit = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.lblMODIntegration2 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SerialPort1
        '
        Me.SerialPort1.PortName = "COM4"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(446, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(270, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Stack Light Overview"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(46, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(219, 31)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "5100/Standalone"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(47, 123)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(151, 29)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Integration 1:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(93, 163)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(105, 29)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "E-Panel:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(113, 208)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 29)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Z-Axis:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(134, 250)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 29)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Lids:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(47, 294)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(151, 29)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Integration 2:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(429, 123)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(232, 29)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Firmware/Assembly:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(486, 77)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(187, 31)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Projector Area"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(462, 163)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(199, 29)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Focus/Irradiance:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(911, 77)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(111, 31)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Modular"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(831, 123)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(151, 29)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Integration 1:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(877, 163)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(105, 29)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "E-Panel:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(906, 208)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(76, 29)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "MDM:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(897, 250)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(85, 29)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "Z-Axis:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(131, 339)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(67, 29)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "EOL:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(102, 385)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(96, 29)
        Me.Label17.TabIndex = 16
        Me.Label17.Text = "Crating:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(127, 434)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(71, 29)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "CPO:"
        '
        'lbl5100Integration1
        '
        Me.lbl5100Integration1.AutoSize = True
        Me.lbl5100Integration1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5100Integration1.ForeColor = System.Drawing.Color.White
        Me.lbl5100Integration1.Location = New System.Drawing.Point(204, 123)
        Me.lbl5100Integration1.Name = "lbl5100Integration1"
        Me.lbl5100Integration1.Size = New System.Drawing.Size(53, 29)
        Me.lbl5100Integration1.TabIndex = 18
        Me.lbl5100Integration1.Text = "N/A"
        '
        'lbl5100EPanel
        '
        Me.lbl5100EPanel.AutoSize = True
        Me.lbl5100EPanel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5100EPanel.ForeColor = System.Drawing.Color.White
        Me.lbl5100EPanel.Location = New System.Drawing.Point(204, 163)
        Me.lbl5100EPanel.Name = "lbl5100EPanel"
        Me.lbl5100EPanel.Size = New System.Drawing.Size(53, 29)
        Me.lbl5100EPanel.TabIndex = 19
        Me.lbl5100EPanel.Text = "N/A"
        '
        'lbl5100ZAxis
        '
        Me.lbl5100ZAxis.AutoSize = True
        Me.lbl5100ZAxis.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5100ZAxis.ForeColor = System.Drawing.Color.White
        Me.lbl5100ZAxis.Location = New System.Drawing.Point(204, 208)
        Me.lbl5100ZAxis.Name = "lbl5100ZAxis"
        Me.lbl5100ZAxis.Size = New System.Drawing.Size(53, 29)
        Me.lbl5100ZAxis.TabIndex = 20
        Me.lbl5100ZAxis.Text = "N/A"
        '
        'lbl5100Lids
        '
        Me.lbl5100Lids.AutoSize = True
        Me.lbl5100Lids.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5100Lids.ForeColor = System.Drawing.Color.White
        Me.lbl5100Lids.Location = New System.Drawing.Point(204, 250)
        Me.lbl5100Lids.Name = "lbl5100Lids"
        Me.lbl5100Lids.Size = New System.Drawing.Size(53, 29)
        Me.lbl5100Lids.TabIndex = 21
        Me.lbl5100Lids.Text = "N/A"
        '
        'lbl5100Integration2
        '
        Me.lbl5100Integration2.AutoSize = True
        Me.lbl5100Integration2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5100Integration2.ForeColor = System.Drawing.Color.White
        Me.lbl5100Integration2.Location = New System.Drawing.Point(204, 294)
        Me.lbl5100Integration2.Name = "lbl5100Integration2"
        Me.lbl5100Integration2.Size = New System.Drawing.Size(53, 29)
        Me.lbl5100Integration2.TabIndex = 22
        Me.lbl5100Integration2.Text = "N/A"
        '
        'lblEOL
        '
        Me.lblEOL.AutoSize = True
        Me.lblEOL.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEOL.ForeColor = System.Drawing.Color.White
        Me.lblEOL.Location = New System.Drawing.Point(204, 339)
        Me.lblEOL.Name = "lblEOL"
        Me.lblEOL.Size = New System.Drawing.Size(53, 29)
        Me.lblEOL.TabIndex = 23
        Me.lblEOL.Text = "N/A"
        '
        'lblCrating
        '
        Me.lblCrating.AutoSize = True
        Me.lblCrating.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCrating.ForeColor = System.Drawing.Color.White
        Me.lblCrating.Location = New System.Drawing.Point(204, 385)
        Me.lblCrating.Name = "lblCrating"
        Me.lblCrating.Size = New System.Drawing.Size(53, 29)
        Me.lblCrating.TabIndex = 24
        Me.lblCrating.Text = "N/A"
        '
        'lblCPO
        '
        Me.lblCPO.AutoSize = True
        Me.lblCPO.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCPO.ForeColor = System.Drawing.Color.White
        Me.lblCPO.Location = New System.Drawing.Point(204, 434)
        Me.lblCPO.Name = "lblCPO"
        Me.lblCPO.Size = New System.Drawing.Size(53, 29)
        Me.lblCPO.TabIndex = 25
        Me.lblCPO.Text = "N/A"
        '
        'lblFirmAssem
        '
        Me.lblFirmAssem.AutoSize = True
        Me.lblFirmAssem.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirmAssem.ForeColor = System.Drawing.Color.White
        Me.lblFirmAssem.Location = New System.Drawing.Point(667, 123)
        Me.lblFirmAssem.Name = "lblFirmAssem"
        Me.lblFirmAssem.Size = New System.Drawing.Size(53, 29)
        Me.lblFirmAssem.TabIndex = 26
        Me.lblFirmAssem.Text = "N/A"
        '
        'lblFocusIrr
        '
        Me.lblFocusIrr.AutoSize = True
        Me.lblFocusIrr.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFocusIrr.ForeColor = System.Drawing.Color.White
        Me.lblFocusIrr.Location = New System.Drawing.Point(667, 163)
        Me.lblFocusIrr.Name = "lblFocusIrr"
        Me.lblFocusIrr.Size = New System.Drawing.Size(53, 29)
        Me.lblFocusIrr.TabIndex = 27
        Me.lblFocusIrr.Text = "N/A"
        '
        'lblMODIntegration1
        '
        Me.lblMODIntegration1.AutoSize = True
        Me.lblMODIntegration1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMODIntegration1.ForeColor = System.Drawing.Color.White
        Me.lblMODIntegration1.Location = New System.Drawing.Point(988, 123)
        Me.lblMODIntegration1.Name = "lblMODIntegration1"
        Me.lblMODIntegration1.Size = New System.Drawing.Size(53, 29)
        Me.lblMODIntegration1.TabIndex = 28
        Me.lblMODIntegration1.Text = "N/A"
        '
        'lblModEPanel
        '
        Me.lblModEPanel.AutoSize = True
        Me.lblModEPanel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblModEPanel.ForeColor = System.Drawing.Color.White
        Me.lblModEPanel.Location = New System.Drawing.Point(988, 163)
        Me.lblModEPanel.Name = "lblModEPanel"
        Me.lblModEPanel.Size = New System.Drawing.Size(53, 29)
        Me.lblModEPanel.TabIndex = 29
        Me.lblModEPanel.Text = "N/A"
        '
        'lblMDM
        '
        Me.lblMDM.AutoSize = True
        Me.lblMDM.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDM.ForeColor = System.Drawing.Color.White
        Me.lblMDM.Location = New System.Drawing.Point(988, 208)
        Me.lblMDM.Name = "lblMDM"
        Me.lblMDM.Size = New System.Drawing.Size(53, 29)
        Me.lblMDM.TabIndex = 30
        Me.lblMDM.Text = "N/A"
        '
        'lblMODZAxis
        '
        Me.lblMODZAxis.AutoSize = True
        Me.lblMODZAxis.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMODZAxis.ForeColor = System.Drawing.Color.White
        Me.lblMODZAxis.Location = New System.Drawing.Point(988, 250)
        Me.lblMODZAxis.Name = "lblMODZAxis"
        Me.lblMODZAxis.Size = New System.Drawing.Size(53, 29)
        Me.lblMODZAxis.TabIndex = 31
        Me.lblMODZAxis.Text = "N/A"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(591, 359)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(391, 145)
        Me.RichTextBox1.TabIndex = 32
        Me.RichTextBox1.Text = ""
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(64, 475)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(134, 29)
        Me.Label19.TabIndex = 33
        Me.Label19.Text = "Catch Tray:"
        '
        'lblCatchTray
        '
        Me.lblCatchTray.AutoSize = True
        Me.lblCatchTray.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCatchTray.ForeColor = System.Drawing.Color.White
        Me.lblCatchTray.Location = New System.Drawing.Point(204, 475)
        Me.lblCatchTray.Name = "lblCatchTray"
        Me.lblCatchTray.Size = New System.Drawing.Size(53, 29)
        Me.lblCatchTray.TabIndex = 34
        Me.lblCatchTray.Text = "N/A"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(93, 517)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(102, 29)
        Me.Label20.TabIndex = 35
        Me.Label20.Text = "Ship Kit:"
        '
        'lblShipKit
        '
        Me.lblShipKit.AutoSize = True
        Me.lblShipKit.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShipKit.ForeColor = System.Drawing.Color.White
        Me.lblShipKit.Location = New System.Drawing.Point(204, 517)
        Me.lblShipKit.Name = "lblShipKit"
        Me.lblShipKit.Size = New System.Drawing.Size(53, 29)
        Me.lblShipKit.TabIndex = 36
        Me.lblShipKit.Text = "N/A"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(831, 294)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(151, 29)
        Me.Label21.TabIndex = 37
        Me.Label21.Text = "Integration 2:"
        '
        'lblMODIntegration2
        '
        Me.lblMODIntegration2.AutoSize = True
        Me.lblMODIntegration2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMODIntegration2.ForeColor = System.Drawing.Color.White
        Me.lblMODIntegration2.Location = New System.Drawing.Point(988, 294)
        Me.lblMODIntegration2.Name = "lblMODIntegration2"
        Me.lblMODIntegration2.Size = New System.Drawing.Size(53, 29)
        Me.lblMODIntegration2.TabIndex = 38
        Me.lblMODIntegration2.Text = "N/A"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(331, 218)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(240, 150)
        Me.DataGridView1.TabIndex = 39
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(1300, 565)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.lblMODIntegration2)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.lblShipKit)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.lblCatchTray)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.lblMODZAxis)
        Me.Controls.Add(Me.lblMDM)
        Me.Controls.Add(Me.lblModEPanel)
        Me.Controls.Add(Me.lblMODIntegration1)
        Me.Controls.Add(Me.lblFocusIrr)
        Me.Controls.Add(Me.lblFirmAssem)
        Me.Controls.Add(Me.lblCPO)
        Me.Controls.Add(Me.lblCrating)
        Me.Controls.Add(Me.lblEOL)
        Me.Controls.Add(Me.lbl5100Integration2)
        Me.Controls.Add(Me.lbl5100Lids)
        Me.Controls.Add(Me.lbl5100ZAxis)
        Me.Controls.Add(Me.lbl5100EPanel)
        Me.Controls.Add(Me.lbl5100Integration1)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents lbl5100Integration1 As Label
    Friend WithEvents lbl5100EPanel As Label
    Friend WithEvents lbl5100ZAxis As Label
    Friend WithEvents lbl5100Lids As Label
    Friend WithEvents lbl5100Integration2 As Label
    Friend WithEvents lblEOL As Label
    Friend WithEvents lblCrating As Label
    Friend WithEvents lblCPO As Label
    Friend WithEvents lblFirmAssem As Label
    Friend WithEvents lblFocusIrr As Label
    Friend WithEvents lblMODIntegration1 As Label
    Friend WithEvents lblModEPanel As Label
    Friend WithEvents lblMDM As Label
    Friend WithEvents lblMODZAxis As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents lblCatchTray As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lblShipKit As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents lblMODIntegration2 As Label
    Friend WithEvents DataGridView1 As DataGridView
End Class
