﻿Imports System.IO.Ports
Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class Form1
    Dim StrBuffer As String
    Delegate Sub InvokeDelegate()
    Dim ConnString As String = "Data Source=DESKTOP-OSRNAUL\SQLEXPRESS; Integrated Security=True"
    Public StationID As Integer
    Public LightID As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try

            SerialPort1.Open()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub SerialPort1_DataReceived(sender As Object, e As SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived

        'Searching for data input
        Dim ReadCode As String
        ReadCode = SerialPort1.ReadLine

        'Print the button press
        RichTextBox1.Invoke(New MethodInvoker(Sub() RichTextBox1.Text = ReadCode), Nothing)


        UpdateTextRequest(ReadCode)

    End Sub

    Private Sub UpdateTextRequest(code As String)

        'If RichTextBox1.InvokeRequired Then
        '    RichTextBox1.Invoke(Sub() UpdateTextRequest(code))

        If lbl5100Integration1.InvokeRequired Then
            lbl5100Integration1.Invoke(Sub() UpdateTextRequest(code))

            'MsgBox(code)


        Else
            If code.Substring(1, 1) = " " Then
                '------------------------5100EPanel
                If code.Contains("1 G") Then
                    StationID = 7
                    LightID = 1
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100EPanel.Text = "Running"
                    lbl5100EPanel.ForeColor = Color.Green
                ElseIf code.Contains("1 Y") Then
                    StationID = 7
                    LightID = 2
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100EPanel.Text = "Idle"
                    lbl5100EPanel.ForeColor = Color.Yellow
                ElseIf code.Contains("1 R") Then
                    StationID = 7
                    LightID = 3
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100EPanel.Text = "Down"
                    lbl5100EPanel.ForeColor = Color.Red
                ElseIf code.Contains("1 O") Then
                    StationID = 7
                    LightID = 5
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100EPanel.Text = "Off"
                    lbl5100EPanel.ForeColor = Color.White
                ElseIf code.Contains("1 P") Then
                    StationID = 7
                    LightID = 4
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100EPanel.Text = "Error"
                    lbl5100EPanel.ForeColor = Color.Purple

                    '---------------------5100Integration1
                ElseIf code.Contains("2 G") Then
                    StationID = 6
                    LightID = 1
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100Integration1.Text = "Running"
                    lbl5100Integration1.ForeColor = Color.Green
                ElseIf code.Contains("2 Y") Then
                    StationID = 6
                    LightID = 2
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100Integration1.Text = "Idle"
                    lbl5100Integration1.ForeColor = Color.Yellow
                ElseIf code.Contains("2 R") Then
                    StationID = 6
                    LightID = 3
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100Integration1.Text = "Down"
                    lbl5100Integration1.ForeColor = Color.Red
                ElseIf code.Contains("2 O") Then
                    StationID = 6
                    LightID = 5
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100Integration1.Text = "Off"
                    lbl5100Integration1.ForeColor = Color.White
                ElseIf code.Contains("2 P") Then
                    StationID = 6
                    LightID = 4
                    CloseLastStamp()
                    TurnOnNewLight()
                    lbl5100Integration1.Text = "Error"
                    lbl5100Integration1.ForeColor = Color.Purple

                    '---------------------dental lid
                ElseIf code.Contains("3 G") Then
                    lbl5100Lids.Text = "Running"
                    lbl5100Lids.ForeColor = Color.Green
                ElseIf code.Contains("3 Y") Then
                    lbl5100Lids.Text = "Idle"
                    lbl5100Lids.ForeColor = Color.Yellow
                ElseIf code.Contains("3 R") Then
                    lbl5100Lids.Text = "Down"
                    lbl5100Lids.ForeColor = Color.Red
                ElseIf code.Contains("3 O") Then
                    lbl5100Lids.Text = "Off"
                    lbl5100Lids.ForeColor = Color.White
                ElseIf code.Contains("3 P") Then
                    lbl5100Lids.Text = "Error"
                    lbl5100Lids.ForeColor = Color.Purple

                    '---------------------dent z axis
                ElseIf code.Contains("4 G") Then
                    lbl5100ZAxis.Text = "Running"
                    lbl5100ZAxis.ForeColor = Color.Green
                ElseIf code.Contains("4 Y") Then
                    lbl5100ZAxis.Text = "Idle"
                    lbl5100ZAxis.ForeColor = Color.Yellow
                ElseIf code.Contains("4 R") Then
                    lbl5100ZAxis.Text = "Down"
                    lbl5100ZAxis.ForeColor = Color.Red
                ElseIf code.Contains("4 O") Then
                    lbl5100ZAxis.Text = "Off"
                    lbl5100ZAxis.ForeColor = Color.White
                ElseIf code.Contains("4 P") Then
                    lbl5100ZAxis.Text = "Error"
                    lbl5100ZAxis.ForeColor = Color.Purple

                    '---------------------dent z integration 2
                ElseIf code.Contains("5 G") Then
                    lbl5100Integration2.Text = "Running"
                    lbl5100Integration2.ForeColor = Color.Green
                ElseIf code.Contains("5 Y") Then
                    lbl5100Integration2.Text = "Idle"
                    lbl5100Integration2.ForeColor = Color.Yellow
                ElseIf code.Contains("5 R") Then
                    lbl5100Integration2.Text = "Down"
                    lbl5100Integration2.ForeColor = Color.Red
                ElseIf code.Contains("5 O") Then
                    lbl5100Integration2.Text = "Off"
                    lbl5100Integration2.ForeColor = Color.White
                ElseIf code.Contains("5 P") Then
                    lbl5100Integration2.Text = "Error"
                    lbl5100Integration2.ForeColor = Color.Purple

                    '---------------------dent eol
                ElseIf code.Contains("6 G") Then
                    lblEOL.Text = "Running"
                    lblEOL.ForeColor = Color.Green
                ElseIf code.Contains("6 Y") Then
                    lblEOL.Text = "Idle"
                    lblEOL.ForeColor = Color.Yellow
                ElseIf code.Contains("6 R") Then
                    lblEOL.Text = "Down"
                    lblEOL.ForeColor = Color.Red
                ElseIf code.Contains("6 O") Then
                    lblEOL.Text = "Off"
                    lblEOL.ForeColor = Color.White
                ElseIf code.Contains("6 P") Then
                    lblEOL.Text = "Error"
                    lblEOL.ForeColor = Color.Purple

                    '---------------------projector assem/firm
                ElseIf code.Contains("7 G") Then
                    lblFirmAssem.Text = "Running"
                    lblFirmAssem.ForeColor = Color.Green
                ElseIf code.Contains("7 Y") Then
                    lblFirmAssem.Text = "Idle"
                    lblFirmAssem.ForeColor = Color.Yellow
                ElseIf code.Contains("7 R") Then
                    lblFirmAssem.Text = "Down"
                    lblFirmAssem.ForeColor = Color.Red
                ElseIf code.Contains("7 O") Then
                    lblFirmAssem.Text = "Off"
                    lblFirmAssem.ForeColor = Color.White
                ElseIf code.Contains("7 P") Then
                    lblFirmAssem.Text = "Error"
                    lblFirmAssem.ForeColor = Color.Purple

                    '---------------------projector Focus/Irr
                ElseIf code.Contains("8 G") Then
                    lblFocusIrr.Text = "Running"
                    lblFocusIrr.ForeColor = Color.Green
                ElseIf code.Contains("8 Y") Then
                    lblFocusIrr.Text = "Idle"
                    lblFocusIrr.ForeColor = Color.Yellow
                ElseIf code.Contains("8 R") Then
                    lblFocusIrr.Text = "Down"
                    lblFocusIrr.ForeColor = Color.Red
                ElseIf code.Contains("8 O") Then
                    lblFocusIrr.Text = "Off"
                    lblFocusIrr.ForeColor = Color.White
                ElseIf code.Contains("8 P") Then
                    lblFocusIrr.Text = "Error"
                    lblFocusIrr.ForeColor = Color.Purple

                    '---------------------catch tray
                ElseIf code.Contains("9 G") Then
                    lblCatchTray.Text = "Running"
                    lblCatchTray.ForeColor = Color.Green
                ElseIf code.Contains("9 Y") Then
                    lblCatchTray.Text = "Idle"
                    lblCatchTray.ForeColor = Color.Yellow
                ElseIf code.Contains("9 R") Then
                    lblCatchTray.Text = "Down"
                    lblCatchTray.ForeColor = Color.Red
                ElseIf code.Contains("9 O") Then
                    lblCatchTray.Text = "Off"
                    lblCatchTray.ForeColor = Color.White
                ElseIf code.Contains("9 P") Then
                    lblCatchTray.Text = "Error"
                    lblCatchTray.ForeColor = Color.Purple
                End If

            Else
                '-----------------------------------Begin double digit station numbers-------------------------
                '---------------------ship kit
                If code.Contains("10 G") Then
                    lblShipKit.Text = "Running"
                    lblShipKit.ForeColor = Color.Green
                ElseIf code.Contains("10 Y") Then
                    lblShipKit.Text = "Idle"
                    lblShipKit.ForeColor = Color.Yellow
                ElseIf code.Contains("10 R") Then
                    lblShipKit.Text = "Down"
                    lblShipKit.ForeColor = Color.Red
                ElseIf code.Contains("10 O") Then
                    lblShipKit.Text = "Off"
                    lblShipKit.ForeColor = Color.White
                ElseIf code.Contains("10 P") Then
                    lblShipKit.Text = "Error"
                    lblShipKit.ForeColor = Color.Purple

                    '---------------------crating
                ElseIf code.Contains("11 G") Then
                    lblCrating.Text = "Running"
                    lblCrating.ForeColor = Color.Green
                ElseIf code.Contains("11 Y") Then
                    lblCrating.Text = "Idle"
                    lblCrating.ForeColor = Color.Yellow
                ElseIf code.Contains("11 R") Then
                    lblCrating.Text = "Down"
                    lblCrating.ForeColor = Color.Red
                ElseIf code.Contains("11 O") Then
                    lblCrating.Text = "Off"
                    lblCrating.ForeColor = Color.White
                ElseIf code.Contains("11 P") Then
                    lblCrating.Text = "Error"
                    lblCrating.ForeColor = Color.Purple

                    '---------------------CPO
                ElseIf code.Contains("12 G") Then
                    lblCPO.Text = "Running"
                    lblCPO.ForeColor = Color.Green
                ElseIf code.Contains("12 Y") Then
                    lblCPO.Text = "Idle"
                    lblCPO.ForeColor = Color.Yellow
                ElseIf code.Contains("12 R") Then
                    lblCPO.Text = "Down"
                    lblCPO.ForeColor = Color.Red
                ElseIf code.Contains("12 O") Then
                    lblCPO.Text = "Off"
                    lblCPO.ForeColor = Color.White
                ElseIf code.Contains("12 P") Then
                    lblCPO.Text = "Error"
                    lblCPO.ForeColor = Color.Purple

                    '---------------------MOD E-Panel
                ElseIf code.Contains("13 G") Then
                    lblModEPanel.Text = "Running"
                    lblModEPanel.ForeColor = Color.Green
                ElseIf code.Contains("13 Y") Then
                    lblModEPanel.Text = "Idle"
                    lblModEPanel.ForeColor = Color.Yellow
                ElseIf code.Contains("13 R") Then
                    lblModEPanel.Text = "Down"
                    lblModEPanel.ForeColor = Color.Red
                ElseIf code.Contains("13 O") Then
                    lblModEPanel.Text = "Off"
                    lblModEPanel.ForeColor = Color.White
                ElseIf code.Contains("13 P") Then
                    lblModEPanel.Text = "Error"
                    lblModEPanel.ForeColor = Color.Purple

                    '---------------------MOD integration 1
                ElseIf code.Contains("14 G") Then
                    lblMODIntegration1.Text = "Running"
                    lblMODIntegration1.ForeColor = Color.Green
                ElseIf code.Contains("14 Y") Then
                    lblMODIntegration1.Text = "Idle"
                    lblMODIntegration1.ForeColor = Color.Yellow
                ElseIf code.Contains("14 R") Then
                    lblMODIntegration1.Text = "Down"
                    lblMODIntegration1.ForeColor = Color.Red
                ElseIf code.Contains("14 O") Then
                    lblMODIntegration1.Text = "Off"
                    lblMODIntegration1.ForeColor = Color.White
                ElseIf code.Contains("14 P") Then
                    lblMODIntegration1.Text = "Error"
                    lblMODIntegration1.ForeColor = Color.Purple

                    '---------------------MOD integration 2
                ElseIf code.Contains("15 G") Then
                    lblMODIntegration2.Text = "Running"
                    lblMODIntegration2.ForeColor = Color.Green
                ElseIf code.Contains("15 Y") Then
                    lblMODIntegration2.Text = "Idle"
                    lblMODIntegration2.ForeColor = Color.Yellow
                ElseIf code.Contains("15 R") Then
                    lblMODIntegration2.Text = "Down"
                    lblMODIntegration2.ForeColor = Color.Red
                ElseIf code.Contains("15 O") Then
                    lblMODIntegration2.Text = "Off"
                    lblMODIntegration2.ForeColor = Color.White
                ElseIf code.Contains("15 P") Then
                    lblMODIntegration2.Text = "Error"
                    lblMODIntegration2.ForeColor = Color.Purple

                    '---------------------MOD MDM
                ElseIf code.Contains("16 G") Then
                    lblMDM.Text = "Running"
                    lblMDM.ForeColor = Color.Green
                ElseIf code.Contains("16 Y") Then
                    lblMDM.Text = "Idle"
                    lblMDM.ForeColor = Color.Yellow
                ElseIf code.Contains("16 R") Then
                    lblMDM.Text = "Down"
                    lblMDM.ForeColor = Color.Red
                ElseIf code.Contains("16 O") Then
                    lblMDM.Text = "Off"
                    lblMDM.ForeColor = Color.White
                ElseIf code.Contains("16 P") Then
                    lblMDM.Text = "Error"
                    lblMDM.ForeColor = Color.Purple

                    '---------------------MOD ZAxis
                ElseIf code.Contains("17 G") Then
                    lblMODZAxis.Text = "Running"
                    lblMODZAxis.ForeColor = Color.Green
                ElseIf code.Contains("17 Y") Then
                    lblMODZAxis.Text = "Idle"
                    lblMODZAxis.ForeColor = Color.Yellow
                ElseIf code.Contains("17 R") Then
                    lblMODZAxis.Text = "Down"
                    lblMODZAxis.ForeColor = Color.Red
                ElseIf code.Contains("17 O") Then
                    lblMODZAxis.Text = "Off"
                    lblMODZAxis.ForeColor = Color.White
                ElseIf code.Contains("17 P") Then
                    lblMODZAxis.Text = "Error"
                    lblMODZAxis.ForeColor = Color.Purple

                End If

            End If
        End If


    End Sub

    Private Sub CloseLastStamp()

        Using conn1 As New SqlConnection(ConnString)
            conn1.Open()
            Using comm1 As New SqlCommand("SELECT * FROM SanminaRH.dbo.tblLightStamps WHERE StationID = @ID AND TimeEnd is NULL", conn1)
                comm1.Parameters.AddWithValue("@ID", StationID)
                Dim dt As New DataTable
                Dim sql As New SqlDataAdapter(comm1)
                sql.Fill(dt)
                For Each row As DataRow In dt.Rows
                    Using conn2 As New SqlConnection(ConnString)
                        conn2.Open()
                        Using comm2 As New SqlCommand("UPDATE SanminaRH.dbo.tblLightStamps SET TimeEND = getdate() WHERE StationID = @ID AND TimeEnd IS NULL", conn2)
                            comm2.Parameters.AddWithValue("@ID", StationID)
                            comm2.ExecuteNonQuery()
                        End Using
                        conn2.Close()
                    End Using
                Next
            End Using
            conn1.Close()
        End Using

    End Sub

    Private Sub TurnOnNewLight()

        Using conn1 As New SqlConnection(ConnString)
            conn1.Open()
            Using comm1 As New SqlCommand("SELECT * FROM SanminaRH.dbo.tblLightStamps WHERE StationID = @ID AND TimeEnd IS NULL", conn1)
                comm1.Parameters.AddWithValue("@ID", StationID)
                Dim dt As New DataTable
                Dim sql As New SqlDataAdapter(comm1)
                sql.Fill(dt)
                If dt.Rows.Count >= 1 Then
                    CloseLastStamp()
                End If
            End Using
            conn1.Close()
        End Using

        Using conn1 As New SqlConnection(ConnString)
            conn1.Open()
            Using comm1 As New SqlCommand("INSERT INTO SanminaRH.dbo.tblLightStamps (LightID, StationID, TimeStart) " _
                                         & "VALUES (@LightID, @StationID, getdate())", conn1)
                With comm1.Parameters
                    .AddWithValue("@LightID", LightID)
                    .AddWithValue("@StationID", StationID)
                End With
                comm1.ExecuteNonQuery()
            End Using
            conn1.Close()
        End Using

    End Sub

End Class
